#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    https://shiny.posit.co/
#

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Old Faithful Geyser Data"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("bins",
                        "Number of bins:",
                        min = 1,
                        max = 50,
                        value = 30)
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("distPlot")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$distPlot <- renderPlot({
        # generate bins based on input$bins from ui.R
        x    <- faithful[, 2]
        bins <- seq(min(x), max(x), length.out = input$bins + 1)

        # draw the histogram with the specified number of bins
        hist(x, breaks = bins, col = 'darkgray', border = 'white',
             xlab = 'Waiting time to next eruption (in mins)',
             main = 'Histogram of waiting times')
    })
}

# Run the application 
shinyApp(ui = ui, server = server)

library(shiny)
library(tuneR)
library(seewave)
library(caret)

# Assuming your model is already trained and available as 'model'
# If saved to a file, load it like this:
# model <- readRDS("model.rds")

ui <- fluidPage(
  titlePanel("🎤 Voice Sentiment Analyzer"),
  
  sidebarLayout(
    sidebarPanel(
      fileInput("audio", "Upload a WAV File", accept = ".wav"),
      actionButton("analyze", "Analyze Emotion")
    ),
    
    mainPanel(
      h3("Predicted Emotion:"),
      verbatimTextOutput("emotion_output")
    )
  )
)

server <- function(input, output) {
  observeEvent(input$analyze, {
    req(input$audio)
    
    file_path <- input$audio$datapath
    audio <- readWave(file_path)
    audio_mono <- mono(audio, "left")
    audio_data <- audio_mono@left / 2^(audio_mono@bit - 1)
    sr <- audio_mono@samp.rate
    
    # Clip 1 second max for consistency
    max_samples <- min(length(audio_data), sr * 1)
    audio_clip <- audio_data[1:max_samples]
    
    # Extract features
    zcr_val <- mean(zcr(audio_clip, f = sr))
    spectrum <- spec(audio_clip, f = sr, plot = FALSE)
    props <- specprop(spectrum)
    
    centroid_val <- mean(props$cent)
    rolloff_val <- quantile(audio_clip, 0.85)
    duration_val <- length(audio_clip) / sr
    
    input_df <- data.frame(
      zcr = zcr_val,
      centroid = centroid_val,
      rolloff = rolloff_val,
      duration = duration_val
    )
    
    prediction <- predict(model, newdata = input_df)
    
    output$emotion_output <- renderText({
      paste("🧠 Detected Mood:", prediction)
    })
  })
}

shinyApp(ui = ui, server = server)

