audio_files <- list.files(path = ".", pattern = "\\.wav$", full.names = TRUE, recursive = TRUE)
length(audio_files)  # This should return 2880

library(tuneR)
library(seewave)

# Read the first audio file
sample_file <- audio_files[1]
audio <- readWave(sample_file)

# Convert to mono and normalize
audio_mono <- mono(audio, "left")
audio_data <- audio_mono@left / 2^(audio_mono@bit - 1)
sr <- audio_mono@samp.rate

# Use only the first 1 second (or min(1s, total))
max_samples <- min(length(audio_data), sr * 1)
audio_clip <- audio_data[1:max_samples]

# Extract features safely
zcr_val <- mean(zcr(audio_clip, f = sr))
spectrum <- spec(audio_clip, f = sr, plot = FALSE)
props <- specprop(spectrum)

centroid_val <- mean(props$cent)
rolloff_val <- quantile(audio_clip, 0.85)
duration_val <- length(audio_clip) / sr

# Final feature set
c(zcr = zcr_val, centroid = centroid_val, rolloff = rolloff_val, duration = duration_val)

# FEATURE EXTRACT ---------------------------------------------------------

extract_features <- function(file_path) {
  tryCatch({
    audio <- readWave(file_path)
    audio_mono <- mono(audio, "left")
    audio_data <- audio_mono@left / 2^(audio_mono@bit - 1)
    sr <- audio_mono@samp.rate
    
    max_samples <- min(length(audio_data), sr * 1)
    audio_clip <- audio_data[1:max_samples]
    
    zcr_val <- mean(zcr(audio_clip, f = sr))
    spectrum <- spec(audio_clip, f = sr, plot = FALSE)
    props <- specprop(spectrum)
    
    centroid_val <- mean(props$cent)
    rolloff_val <- quantile(audio_clip, 0.85)
    duration_val <- length(audio_clip) / sr
    
    return(c(zcr = zcr_val, centroid = centroid_val, rolloff = rolloff_val, duration = duration_val))
  }, error = function(e) {
    message(paste("Skipping file:", basename(file_path), "due to error:", e$message))
    return(rep(NA, 4))
  })
}

# Apply to all files
features_matrix <- t(sapply(audio_files, extract_features))

# Convert to data frame
features_df <- as.data.frame(features_matrix)
colnames(features_df) <- c("zcr", "centroid", "rolloff", "duration")
features_df$filename <- basename(audio_files)

# View the first few rows
head(features_df)






# Extract emotion code from filename
get_emotion_label <- function(filename) {
  parts <- unlist(strsplit(filename, "-"))
  code <- as.integer(parts[3])
  emotions <- c("Neutral", "Calm", "Happy", "Sad", "Angry", "Fearful", "Disgust", "Surprised")
  return(emotions[code])
}

# Apply to each filename
features_df$emotion <- sapply(features_df$filename, get_emotion_label)

# Preview
head(features_df)
table(features_df$emotion)


library(caret)
library(dplyr)
library(e1071)

# Remove rows with NA (from skipped files)
features_df <- na.omit(features_df)

# Convert emotion to factor
features_df$emotion <- as.factor(features_df$emotion)

# Split into training and test sets (80-20)
set.seed(123)  # for reproducibility
train_index <- createDataPartition(features_df$emotion, p = 0.8, list = FALSE)
train_data <- features_df[train_index, ]
test_data <- features_df[-train_index, ]

# Train a Random Forest model
model <- train(emotion ~ zcr + centroid + rolloff + duration,
               data = train_data,
               method = "rf",
               trControl = trainControl(method = "cv", number = 5))

# Print model accuracy
print(model)

predictions <- predict(model, newdata = test_data)
confusionMatrix(predictions, test_data$emotion)

